% load('hand_emgforce_all','handemgforce');
% threshold_flex = [];
% threshold_ext = [];
% threshold_force = [];
time = [];
for i = 1:length(handemgforce(:,1))
%     threshold_flex(i,1) = th_flex;
%     threshold_ext(i,1) = th_ext;
%     threshold_force(i,1) = Th_force;
    time(i,1) = (i-1)*0.5;
end

figure(1)

subplot(611)
plot(time(:,1),handemgforce(:,15),'LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,16),'LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,17),'LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,18),'LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,19),'LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,20),'LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,21),'LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,22),'LineWidth',1);
axis([0 length(time(:,1))*0.5 0 0.5]);
ylabel('EMG signals')

subplot(612)
plot(time(:,1),handemgforce(:,1),'LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,2),'LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,12),'--k','LineWidth',0.5);
hold on
plot(time(:,1),handemgforce(:,13),'.-k','LineWidth',0.5);
legend('Flexor signal','extensor signal','Flexor threshold','Extensor threshold');
axis([0 length(time(:,1))*0.5 0 1]);
ylabel('Flexor and extensor signals')

subplot(613)
% plot(time(:,1),handemgforce(:,8));
% hold on
% plot(time(:,1),handemgforce(:,9));
% hold on
% plot(time(:,1),handemgforce(:,10));
plot(time(:,1),handemgforce(:,11),'LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,14),'--k','LineWidth',1);
% legend('F(1)','F(2)','F(3)','force_threshold');
legend('Overall EMG signal','Overall EMG threshold');
axis([0 length(time(:,1))*0.5 0 2.5]);
ylabel('Overall EMG signal')

subplot(614)
stairs(time(:,1),handemgforce(:,6),'LineWidth',1);
% legend('State machine');
axis([0 length(time(:,1))*0.5 0 5]);
ylabel('State machine')

subplot(615)
stairs(time(:,1),handemgforce(:,7),'LineWidth',1);
% legend('Grasping mode');
axis([0 length(time(:,1))*0.5 0 3]);
ylabel('Classified mode')

subplot(616)
plot(time(:,1),handemgforce(:,3),'--','LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,4),'--x','LineWidth',1);
hold on
plot(time(:,1),handemgforce(:,5),'--','LineWidth',1);
legend('Thumb force','Index finger force','Middle finger force');
axis([0 length(time(:,1))*0.5 -1 12]);
xlabel('Time (s)')
ylabel('Force')

set(gcf,'color','w');